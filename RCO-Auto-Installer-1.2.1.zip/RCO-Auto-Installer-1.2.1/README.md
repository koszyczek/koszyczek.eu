# Roblox Client Optimizer Auto Installer
----------------------------------------------------
## ⚠️I DID NOT MAKE RCO⚠️
### here is the official github repo for RCO:
### https://github.com/L8X/Roblox-Client-Optimizer
----------------------------------------------------

# About
This is a github repository that currently contains 2 methods of automatically updating RCO and installing it if the user doesn't have RCO. A python script & Batch script. 

# Features
Automatically installs RCO when ran. If you want to know what RCO does check [this](https://github.com/L8X/Roblox-Client-Optimizer#features) out.

# How to use

There are two methods of using the RCO Installer. You can either use the Python version which requires you to install python, or the batch version which only requires you to use Windows as an operating system. Also if it isn't obvious, you need Roblox installed.

### Batch Installer (easiest)
[Downlaod](https://github.com/ShashTheEpic/RCO-Auto-Installer/archive/refs/tags/v1.1.0.zip) the whole repository, unzip it then navigate to `RCO-Auto-Installer-main` -> `Batch Installer` -> `RCO.bat`. Now run `RCO.bat` by opening it. Note that you have to run this everytime Roblox or RCO updates. A future version will include an option to automatically update.

Don't trust `RCO.bat`? Well you can view what the batch script is executing. Open Notepad or any other text editor, press `ctrl + o` and navigate to `RCO.bat`. Open it and you can view the code, with assistance of my comments so you know what's going on.

### Python Installer
First you need python which you can get [here](https://apps.microsoft.com/store/detail/python-311/9NRWMJP3717K). I recommend installng the latest version if possible.
<br>
Now that you have installed python, go ahead and [download](https://github.com/ShashTheEpic/RCO-Auto-Installer/archive/refs/tags/v1.1.0.zip) this repository. Once downloaded, unzip the folder and navigate to `RCO-Auto-Installer-main` -> `Python Installer`. Because this python script uses the request module you have install it. You can do this buy running `Dependencies.bat`. Now to update/install RCO run `Update & Installer.bat`.
<br>
Now everytime you run `Update & Installer.bat` RCO will be updated to the latest version. You can also run the python script in Visual Studio Code.

# FAQ

### Why Does This Exist?
I got bored and sometimes RCO's offical installer doesn't work, so people can use this.

### Something isn't working? Got an error?
Explain your experience [here](https://github.com/ShashTheEpic/RCO-Auto-Installer/issues/new)
