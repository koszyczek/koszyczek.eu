# Python Installer
First you need python which you can get [here](https://apps.microsoft.com/store/detail/python-311/9NRWMJP3717K). I recommend installng the latest version if possible.

Now that you have installed python, go ahead and [download](https://github.com/ShashTheEpic/RCO-Auto-Installer/archive/refs/tags/v1.1.0.zip) this repository. Once downloaded, unzip the folder and navigate to `RCO-Auto-Installer-main` -> `Python Installer`. Because this python script uses the request module you have install it. You can do this buy running `Dependencies.bat`. Now to update/install RCO run `Update & Installer.bat`.

Now everytime you run `Update & Installer.bat` RCO will be updated to the latest version. You can also run the python script in Visual Studio Code.

 Note that you have to run this everytime Roblox or RCO updates. A future version will include an option to automatically update.8