# Batch Installer (easiest)
[Downlaod](https://github.com/ShashTheEpic/RCO-Auto-Installer/archive/refs/tags/v1.1.0.zip) the whole repository, unzip it then navigate to `RCO-Auto-Installer-main` -> `Batch Installer` -> `RCO.bat`. Now run `RCO.bat` by opening it.

If you don't want to download the whole repository, you can just [download](https://github.com/ShashTheEpic/RCO-Auto-Installer/edit/main/Batch%20Installer/RCO.bat) the batch file

Don't trust `RCO.bat`? Well you can view what the batch script is executing. Open Notepad or any other text editora, press `ctrl + o` and navigate to `RCO.bat`. Open it and you can view the code, with assistance of my comments so you know what's going on.

 Note that you have to run this everytime Roblox or RCO updates. A future version will include an option to automatically update.
